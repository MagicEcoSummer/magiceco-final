#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os, sys, time
import bs4, requests, http.client, urllib, urllib.request
import cv2, json, threading
import numpy as np
import xz_rc

from os import path
from urllib.request import urlopen, Request

from PyQt5 import QtCore, uic, QtWidgets, QtGui
from PyQt5.QtCore import QByteArray, qFuzzyCompare, Qt, QTimer
from PyQt5.QtGui import QPalette, QPixmap
from PyQt5.QtMultimedia import *
from PyQt5.QtMultimediaWidgets import *
from PyQt5.QtWidgets import (QAction, QActionGroup, QApplication, QDialog, QMainWindow, QMessageBox)


# # # # # # # # # # # # # # #
from FaceAPI import *       # MS Face API
from SpeechAPI import *     # MS Speech API
from readMp3 import *       # play mp3 file
from dht11_ import *        # sensor
from max30100_ import *     # sensor

from cfg_var import *       # variables that can vary by user environment
# name of variables defined in cfg(msg)_var.py starts with 'cfg(msg)_'
from msg_var import *       # KOR / ENG language is not switchable for now
# # # # # # # # # # # # # # #


# loading PyQt ui files
Main_Window="MainWindow2.ui"
Camera_Window="CameraWindow2.ui"
Login_Window="LoginWindow2.ui"
Join_Window="JoinWindow2.ui"
Measure_Window="MeasureWindow2.ui"

Result_Window="ResultWindow2.ui"
Recommend_Window4="RecommendWindow4.ui"
Recommend_Window5="RecommendWindow5.ui"
Fail_Window="FailWindow2.ui"
YesNo_Window="YesNoWindow2.ui"
Finish_Window="FinishWindow2.ui"
Survey_Window="SurveyWindow2.ui"
Final_Window="FinalWindow2.ui"

Ui_Survey_Window, QtBaseClass =uic.loadUiType(Survey_Window)
Ui_Final_Window, QtBaseClass =uic.loadUiType(Final_Window)

Ui_Main_Window, QtBaseClass =uic.loadUiType(Main_Window)
Ui_Camera_Window, QtBaseClass =uic.loadUiType(Camera_Window)
Ui_Login_Window, QtBaseClass =uic.loadUiType(Login_Window)
Ui_Join_Window, QtBaseClass =uic.loadUiType(Join_Window)
Ui_Measure_Window, QtBaseClass =uic.loadUiType(Measure_Window)

Ui_Result_Window, QtBaseClass =uic.loadUiType(Result_Window)
Ui_Recommend_Window4, QtBaseClass =uic.loadUiType(Recommend_Window4)
Ui_Recommend_Window5, QtBaseClass =uic.loadUiType(Recommend_Window5)

Ui_Fail_Window, QtBaseClass =uic.loadUiType(Fail_Window)
Ui_Finish_Window, QtBaseClass =uic.loadUiType(Finish_Window)


face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
login_flag=0        # 1 - login, 0 - join

nickname=''         # JoinWindow
phone=''            # JoinWindow
sex=''              # JoinWindow
temp=0              # MeasureWindow
weather=''          # MeasureWindow 
age=0
faces=0             # FaceDetectionWidget

heart_rate=0        # sensor
SpO2=0              # sensor
store_temp=0        # sensor
store_humidity=0    # sensor

groupID=sys.argv[1]             # MS Face Group ID
UserName = ''                   # used in Speech API
person_id = ''
person_id2 = ''
faceinfo = {}                   # faceInfo parsed from Face API
sensor_result = False
p_flag = 0
camera_flag=0
r_menu1 = ''
r_menu2 = ''
r_menu3 = ''
r_drink1 = ''
r_drink2 = ''
r_drink3 = ''
menu = []
drink = []
f_menu = []
f_drink = []
order_menu = {"과일&치즈샐러드":0,"라자냐샐러드":1,"비프스테이크수퍼보울":2,"비프크림파스타":3,"쉬림프누들수퍼보울":4,"쉬림프로제파스타":5,"씨푸드파스타":6,"아보카도샌드위치":7,"아보카도연어샐러드":8,"연어샌드위치":9,"연어스테이크수퍼보울":10,"치킨그레인샐러드":11,"치킨샌드위치":12,"치킨스테이크수퍼보울":13,"카프레제샐러드":14,"케일치킨시저샐러드":15,"필리치즈스테이크샌드위치":16,"햄&치즈샐러드":17}
order_drink = {"그래스쿨러(사과,신선초)":0,"그린웨이브(밀싹,케일)":1,"그린호프(케일,샐러리)":2,"당근&비트주스":3,"딸기주스":4,"버진컴백(사과,샐러리)":5,"블루베리&애플주스":6,"비트부스터(비트,오렌지)":7,"스윗조이(파인애플,사과)":8,"스카이워커(당근,사과)":9,"오렌지&애플주스":10,"젠틀바인(비트,자몽)":11,"케일&애플주스":12,"파인애플&애플주스":13,"패스트리스토어(사과,케일)":14,"프로틴블루베리스무디":15,"해피오렌지(오렌지,당근)":16}
final_order_menu=""
final_order_drink=""
survey_num=0


message_CAMERA1 = msg_CAMERA1_KOR   # CameraWindow
message_EMPTY1 = msg_EMPTY1_KOR     # JoinWindow
message_EMPTY2 = msg_EMPTY2_KOR     # JoinWindow
message_PHONE1 = msg_PHONE1_KOR     # JoinWindow & FailWindow
message_PHONE2 = msg_PHONE2_KOR     # JoinWindow & FailWindow
message_SENSOR1 = msg_SENSOR1_KOR     # JoinWindow & FailWindow

# Get data from sensor
def collect_sensor_data ():
    global heart_rate    
    global SpO2
    global store_temp
    global store_humidity

    heart_rate = 0
    store_temp,store_humidity=measure_tem_humi()
    #print(store_temp,store_humidity)
    heart_rate,SpO2=measure_pulse_O2()
    #print(heart_rate,SpO2)
    
    if heart_rate == 0:
        return False
    else:
        return True


# return 1 : correct phone number, return 0 : wrong phone number
def checkPhoneNumber(phone):
    
    if len(phone) == 11:
        for i in range(11):
            if phone[i] <'0' or phone[i]>'9':
                return 0
        return 1
    
    elif len(phone)==13:
        if phone[3]!='-' or phone[8]!='-':
            return 0
        
        for i in range(13):
            if (i!=3 and i!=8) and (phone[i] <'0' or phone[i]>'9'):
                return 0
        return 1
    else:
        return 0


# Naver Weather Info Crawler
def collect_weather_info():
    global temp
    global weather
    
    enc_location=urllib.parse.quote(cfg_LOCATION+'+날씨')
    url='https://search.naver.com/search.naver?ie=utf8&query='+ enc_location

    req=Request(url, headers={'User-Agent':'Mozilla/5.0'})
    page=urlopen(req)
    html=page.read()
    soup=bs4.BeautifulSoup(html,'html.parser')
    
    temp=soup.find('p',class_='info_temperature').find('span',class_='todaytemp').text
    weather=soup.find('ul',class_='info_list').find('p',class_='cast_txt').text       #ex) 구름조금, 어제보다 1도 높음.
    weather=weather.split(',')[0]
    
def recommend_menu():    
    global r_menu1
    global r_menu2
    global r_menu3
    global r_drink1
    global r_drink2
    global r_drink3
    if p_flag == 1:
        if weather == "맑음":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '파인애플&애플주스'
            elif heart_rate<=61:
                r_menu1 = '과일&치즈샐러드'
                r_menu2 = '비프스테이크수퍼보울'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '딸기주스'
            elif heart_rate>=77:
                r_menu1 = '연어스테이크수퍼보울'
                r_menu2 = '치킨스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '그린호프(케일,샐러리)'
                r_drink2 = '버진컴백(사과,샐러리)'
                r_drink3 = '파인애플&애플주스'
        elif weather == "구름조금" or weather == "구름많음":    
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '오렌지&애플주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '과일&치즈샐러드'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '딸기주스'
            elif heart_rate>=77:
                r_menu1 = '치킨스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '딸기주스'
                r_drink2 = '버진컴백(사과,샐러리)'
                r_drink3 = '오렌지&애플주스'
        elif weather == "흐림":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프크림파스타'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '햄&치즈샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '딸기주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '씨푸드파스타'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '딸기주스'
            elif heart_rate>=77:
                r_menu1 = '치킨스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '딸기주스'
                r_drink2 = '버진컴백(사과,샐러리)'
                r_drink3 = '오렌지&애플주스'
        else:
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '딸기주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '씨푸드파스타'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '딸기주스'
            elif heart_rate>=77:
                r_menu1 = '치킨스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '딸기주스'
                r_drink2 = '버진컴백(사과,샐러리)'
                r_drink3 = '오렌지&애플주스'

    elif p_flag == 2:
        if weather == "맑음":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '쉬림프누들수퍼보울'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '패스트리스토어(사과,케일)'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '쉬림프누들수퍼보울'
                r_menu3 = '과일&치즈샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '딸기주스'
            elif heart_rate>=77:
                r_menu1 = '라자냐샐러드'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '카프레제샐러드'
                r_drink1 = '그린웨이브(밀싹,케일)'
                r_drink2 = '패스트리스토어(사과,케일)'
                r_drink3 = '딸기주스'
        elif weather == "구름조금" or weather == "구름많음":    
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '파인애플&애플주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '쉬림프누들수퍼보울'
                r_menu3 = '카프레제샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '케일&애플주스'
            elif heart_rate>=77:
                r_menu1 = '필리치즈스테이크샌드위치'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '카프레제샐러드'
                r_drink1 = '프로틴블루베리스무디'
                r_drink2 = '패스트리스토어(사과,케일)'
                r_drink3 = '그린웨이브(밀싹,케일)'
        elif weather == "흐림":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '씨푸드파스타'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '케일&애플주스'
            elif heart_rate<=61:
                r_menu1 = '아보카도샌드위치'
                r_menu2 = '필리치즈스테이크샌드위치'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '프로틴블루베리스무디'
            elif heart_rate>=77:
                r_menu1 = '씨푸드파스타'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '프로틴블루베리스무디'
                r_drink2 = '패스트리스토어(사과,케일)'
                r_drink3 = '그린웨이브(밀싹,케일)'
        else:
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '씨푸드파스타'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '치킨스테이크수퍼보울'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '케일&애플주스'
            elif heart_rate<=61:
                r_menu1 = '쉬림프로제파스타'
                r_menu2 = '필리치즈스테이크샌드위치'
                r_menu3 = '씨푸드파스타'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '프로틴블루베리스무디'
            elif heart_rate>=77:
                r_menu1 = '라자냐샐러드'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '씨푸드파스타'
                r_drink1 = '프로틴블루베리스무디'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '케일&애플주스'

    elif p_flag == 3:
        if weather == "맑음":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '치킨스테이크수퍼보울'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '버진컴백(사과,샐러리)'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '아보카도연어샐러드'
                r_menu3 = '치킨샌드위치'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '스카이워커(당근,사과)'
            elif heart_rate>=77:
                r_menu1 = '라자냐샐러드'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '치킨그레인샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '그래스쿨러(사과,신선초)'
                r_drink3 = '당근&비트주스'
        elif weather == "구름조금" or weather == "구름많음":    
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어샌드위치'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '블루베리&애플주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '치킨샌드위치'
                r_menu3 = '카프레제샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '스카이워커(당근,사과)'
            elif heart_rate>=77:
                r_menu1 = '카프레제샐러드'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '치킨그레인샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '그래스쿨러(사과,신선초)'
                r_drink3 = '당근&비트주스'
        elif weather == "흐림":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어샌드위치'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '블루베리&애플주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '라자냐샐러드'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '비트부스터(비트,오렌지)'
            elif heart_rate>=77:
                r_menu1 = '치킨샌드위치'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '연어샌드위치'
                r_drink1 = '그래스쿨러(사과,신선초)'
                r_drink2 = '스카이워커(당근,사과)'
                r_drink3 = '케일&애플주스'
        else:
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '라자냐샐러드'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '블루베리&애플주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '치킨샌드위치'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '스윗조이(파인애플,사과)'
                r_drink3 = '비트부스터(비트,오렌지)'
            elif heart_rate>=77:
                r_menu1 = '치킨스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '씨푸드파스타'
                r_drink1 = '당근&비트주스'
                r_drink2 = '블루베리&애플주스'
                r_drink3 = '케일&애플주스'
    
    elif p_flag == 4:
        if weather == "맑음":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '쉬림프누들수퍼보울'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '그린웨이브(밀싹,케일)'
                r_drink3 = '그린호프(케일,샐러리)'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '쉬림프누들수퍼보울'
                r_menu3 = '과일&치즈샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '딸기주스'
                r_drink3 = '그린호프(케일,샐러리)'
            elif heart_rate>=77:
                r_menu1 = '필리치즈스테이크샌드위치'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '아보카도샌드위치'
                r_drink1 = '프로틴블루베리스무디'
                r_drink2 = '그린웨이브(밀싹,케일)'
                r_drink3 = '그린호프(케일,샐러리)'
        elif weather == "구름조금" or weather == "구름많음":    
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '치킨그레인샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '그린웨이브(밀싹,케일)'
                r_drink3 = '블루베리&애플주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '과일&치즈샐러드'
                r_menu3 = '필리치즈스테이크샌드위치'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '딸기주스'
                r_drink3 = '그린호프(케일,샐러리)'
            elif heart_rate>=77:
                r_menu1 = '필리치즈스테이크샌드위치'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '연어샌드위치'
                r_drink1 = '프로틴블루베리스무디'
                r_drink2 = '그린웨이브(밀싹,케일)'
                r_drink3 = '그린호프(케일,샐러리)'
        elif weather == "흐림":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '치킨그레인샐러드'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '햄&치즈샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '그린웨이브(밀싹,케일)'
                r_drink3 = '블루베리&애플주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '쉬림프로제파스타'
                r_menu3 = '필리치즈스테이크샌드위치'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '딸기주스'
                r_drink3 = '그린호프(케일,샐러리)'
            elif heart_rate>=77:
                r_menu1 = '쉬림프누들수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '연어샌드위치'
                r_drink1 = '프로틴블루베리스무디'
                r_drink2 = '그린웨이브(밀싹,케일)'
                r_drink3 = '그린호프(케일,샐러리)'
        else:
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '라자냐샐러드'
                r_menu2 = '쉬림프로제파스타'
                r_menu3 = '비프크림파스타'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '케일&애플주스'
                r_drink3 = '딸기주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '아보카도샌드위치'
                r_menu3 = '필리치즈스테이크샌드위치'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '딸기주스'
                r_drink3 = '케일&애플주스'
            elif heart_rate>=77:
                r_menu1 = '쉬림프누들수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '프로틴블루베리스무디'
                r_drink2 = '딸기주스'
                r_drink3 = '케일&애플주스'
    
    elif p_flag == 5:
        if weather == "맑음":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '쉬림프누들수퍼보울'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '해피오렌지(오렌지,당근)'
                r_drink3 = '블루베리&애플주스'
            elif heart_rate<=61:
                r_menu1 = '쉬림프누들수퍼보울'
                r_menu2 = '필리치즈스테이크샌드위치'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '비트부스터(비트,오렌지)'
                r_drink3 = '해피오렌지(오렌지,당근)'
            elif heart_rate>=77:
                r_menu1 = '과일&치즈샐러드'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '치킨그레인샐러드'
                r_drink1 = '비트부스터(비트,오렌지)'
                r_drink2 = '그린웨이브(밀싹,케일)'
                r_drink3 = '그래스쿨러(사과,신선초)'
        elif weather == "구름조금" or weather == "구름많음":    
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '아보카도샌드위치'
                r_menu3 = '카프레제샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '해피오렌지(오렌지,당근)'
                r_drink3 = '그린호프(케일,샐러리)'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '쉬림프누들수퍼보울'
                r_menu3 = '과일&치즈샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '해피오렌지(오렌지,당근)'
                r_drink3 = '비트부스터(비트,오렌지)'
            elif heart_rate>=77:
                r_menu1 = '필리치즈스테이크샌드위치'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '치킨그레인샐러드'
                r_drink1 = '케일&애플주스'
                r_drink2 = '그린웨이브(밀싹,케일)'
                r_drink3 = '그래스쿨러(사과,신선초)'
        elif weather == "흐림":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어샌드위치'
                r_menu3 = '카프레제샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '해피오렌지(오렌지,당근)'
                r_drink3 = '그린호프(케일,샐러리)'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '쉬림프누들수퍼보울'
                r_menu3 = '치킨그레인샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '해피오렌지(오렌지,당근)'
                r_drink3 = '비트부스터(비트,오렌지)'
            elif heart_rate>=77:
                r_menu1 = '과일&치즈샐러드'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '치킨그레인샐러드'
                r_drink1 = '비트부스터(비트,오렌지)'
                r_drink2 = '그래스쿨러(사과,신선초)'
                r_drink3 = '그린호프(케일,샐러리)'
        else:
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '카프레제샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '해피오렌지(오렌지,당근)'
                r_drink3 = '당근&비트주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '필리치즈스테이크샌드위치'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '비트부스터(비트,오렌지)'
                r_drink3 = '해피오렌지(오렌지,당근)'
            elif heart_rate>=77:
                r_menu1 = '비프크림파스타'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '아보카도샌드위치'
                r_drink1 = '해피오렌지(오렌지,당근)'
                r_drink2 = '케일&애플주스'
                r_drink3 = '당근&비트주스'
    elif p_flag == 6:
        if weather == "맑음":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '아보카도연어샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '블루베리&애플주스'
                r_drink3 = '젠틀바인(비트,자몽)'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '과일&치즈샐러드'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '패스트리스토어(사과,케일)'
                r_drink3 = '젠틀바인(비트,자몽)'
            elif heart_rate>=77:
                r_menu1 = '치킨스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '필리치즈스테이크샌드위치'
                r_drink1 = '프로틴블루베리스무디'
                r_drink2 = '패스트리스토어(사과,케일)'
                r_drink3 = '케일&애플주스'
        elif weather == "구름조금" or weather == "구름많음":    
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '필리치즈스테이크샌드위치'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '파인애플&애플주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '치킨스테이크수퍼보울'
                r_menu3 = '과일&치즈샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '패스트리스토어(사과,케일)'
            elif heart_rate>=77:
                r_menu1 = '치킨스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '치킨샌드위치'
                r_drink1 = '패스트리스토어(사과,케일)'
                r_drink2 = '그린웨이브(밀싹,케일)'
                r_drink3 = '케일&애플주스'
        elif weather == "흐림":
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '케일치킨시저샐러드'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '블루베리&애플주스'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '씨푸드파스타'
                r_menu3 = '필리치즈스테이크샌드위치'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '패스트리스토어(사과,케일)'
            elif heart_rate>=77:
                r_menu1 = '치킨샌드위치'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '씨푸드파스타'
                r_drink1 = '블루베리&애플주스'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '케일&애플주스'
        else:
            if heart_rate>61 and heart_rate<77:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '씨푸드파스타'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '블루베리&애플주스'
                r_drink3 = '젠틀바인(비트,자몽)'
            elif heart_rate<=61:
                r_menu1 = '비프스테이크수퍼보울'
                r_menu2 = '필리치즈스테이크샌드위치'
                r_menu3 = '씨푸드파스타'
                r_drink1 = '스카이워커(당근,사과)'
                r_drink2 = '젠틀바인(비트,자몽)'
                r_drink3 = '블루베리&애플주스'
            elif heart_rate>=77:
                r_menu1 = '치킨샌드위치'
                r_menu2 = '연어스테이크수퍼보울'
                r_menu3 = '라자냐샐러드'
                r_drink1 = '블루베리&애플주스'
                r_drink2 = '케일&애플주스'
                r_drink3 = '당근&비트주스'
class RecordVideo(QtCore.QObject):
    image_data = QtCore.pyqtSignal(np.ndarray)

    def __init__(self, camera_port=0, parent=None):
        super().__init__(parent)
        self.camera = cv2.VideoCapture(camera_port)
        self.timer = QtCore.QBasicTimer()

    def start_recording(self):          
        self.timer.start(0, self)
    def stop_recording(self):           
        self.timer.stop()
        self.camera.release()
        self.camera=cv2.VideoCapture(0)
    def timerEvent(self, event):
        if (event.timerId() != self.timer.timerId()):
            return
        read, data = self.camera.read()
        if read:
            self.image_data.emit(data)


class FaceDetectionWidget(QtWidgets.QWidget):
    def __init__(self, haar_cascade_filepath, parent=None):
        super().__init__(parent)
        self.classifier = cv2.CascadeClassifier(haar_cascade_filepath)
        self.image = QtGui.QImage()
        self._red = (0, 0, 255)
        self._width = 2
        self._min_size = (30, 30)

    def detect_faces(self, image: np.ndarray):
        # haarclassifiers work better in black and white
        global faces
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        gray_image = cv2.equalizeHist(gray_image)
        
        faces = self.classifier.detectMultiScale(gray_image,
                                                 scaleFactor=1.3,
                                                 minNeighbors=4,
                                                 flags=cv2.CASCADE_SCALE_IMAGE,
                                                minSize=self._min_size)

        return faces

    def image_data_slot(self, image_data):
        global faces
        global camera_flag
        global UserName
        global person_id
        global faceinfo
        global person_id2
        global sex
        global age
        faces = self.detect_faces(image_data)

        # draw face rectangle
        for (x, y, w, h) in faces:
            cv2.rectangle(image_data,
                          (x, y),
                          (x+w, y+h),
                          self._red,
                          self._width)
        
        self.image = self.get_qimage(image_data)
        if self.image.size() != self.size():
            self.setFixedSize(self.image.size())

        
        # check if rectangle is bigger than certain size
        if camera_flag == 1 and (type(faces) is not tuple and faces[0][3] >250 ):
            cv2.imwrite('try.jpg',image_data)

            CameraWindow1.record_video.stop_recording()

            if login_flag==1:               # login
                api_result, faceinfo, person_id2, UserName = face_api(True,nickname,groupID)
                if api_result == False:     # Face API Fail 2 or 3
                                            # Fail 2 - No Face Detected
                                            # Fail 3 - Nobody Matched
                    FailWindow1.showFullScreen()

                else :                      # Face API Success 2
                    s_data={'personid':person_id2}
                    rep2=requests.get(cfg_SERVER_URL2,params=s_data)
                    r_data = rep2.json()
                    #print(r_data)
                    #print(r_data)
                    sex = r_data['sex']
                    age = float(faceinfo['age'])
                    MeasureWindow1.showFullScreen()
                    MeasureWindow1.Measure()

                    
            else:                           # Join
                UserName = nickname
                api_result, faceinfo, person_id = face_api(False,nickname,groupID)
                age = float(faceinfo['age'])
                data={'id':nickname, 'phone':phone,'sex':sex,'weather':weather,'personid':person_id,'age':faceinfo['age'],'storeid':cfg_LOCATION, 'temp':temp,'faceinfo':json.dumps(faceinfo)}
                rep=requests.post(cfg_SERVER_URL,json=data)
                MeasureWindow1.showFullScreen()
                MeasureWindow1.Measure()

            camera_flag=0
            CameraWindow1.close()
    
        else:
            self.update()
    
    def get_qimage(self, image: np.ndarray):
        height, width, colors = image.shape
        bytesPerLine = 3 * width
        QImage = QtGui.QImage

        image = QImage(image.data,
                       width,
                       height,
                       bytesPerLine,
                       QImage.Format_RGB888)

        image = image.rgbSwapped()
        return image

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        painter.drawImage(0, 0, self.image)
        self.image = QtGui.QImage()


# Main Window with background image
# Touch input changes MainWindow to LoginWindow
class MainWindow(QtWidgets.QMainWindow, Ui_Main_Window):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Main_Window.__init__(self)
        self.setupUi(self)
        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(32)
        self.label_main.setFont(font)
        self.label_main.setAlignment(QtCore.Qt.AlignCenter)
        self.label_main.setObjectName("label_main")
        self.pushButton_Main.clicked.connect(self.Main_button_clicked)
        self.pushButton_main_next.clicked.connect(self.Main_button_clicked)
    
    def Main_button_clicked(self):
        collect_weather_info()
        LoginWindow1.showFullScreen()
        self.close()
    

# Login button & Join button
# Login button touched -> CameraWindow
# Join  button touched -> JoinWindow
class LoginWindow(QtWidgets.QMainWindow, Ui_Login_Window):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Login_Window.__init__(self)
        self.setupUi(self)
        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(24)
        self.label_join.setFont(font)
        self.label_join.setAlignment(QtCore.Qt.AlignCenter)
        self.label_join.setObjectName("label_join")

        self.label_login.setFont(font)
        self.label_login.setAlignment(QtCore.Qt.AlignCenter)
        self.label_login.setObjectName("label_login")
        self.pushButton_login.clicked.connect(self.Login_login_button_clicked)
        self.pushButton_join.clicked.connect(self.Login_join_button_clicked)
        
    def Login_login_button_clicked(self):
        global login_flag
        global camera_flag

        login_flag=1
        camera_flag=1
        CameraWindow1.record_video.start_recording()
        CameraWindow1.showFullScreen()
        self.close()
        
    def Login_join_button_clicked(self):
        JoinWindow1.showFullScreen()
        self.close()


# Camera method powered by OpenCV
# When detected face size exceeds certain value, FaceAPI is called
class CameraWindow(QtWidgets.QMainWindow, Ui_Camera_Window):
    def __init__(self,haar_cascade_filepath):
        super().__init__()
        self.setupUI()

    def setupUI(self):
        self.setGeometry(0, 0, 800, 480)
        self.centralwidget=QtWidgets.QWidget(self)

        # Defines entire camera screen label
        self.camera_main_label=QtWidgets.QLabel(self.centralwidget)
        self.camera_main_label.setGeometry(QtCore.QRect(-1, -1, 800, 480))
        self.camera_main_label.setStyleSheet("border-image: url(:/newPrefix/image/juicebro.jpg);")
        self.camera_main_label.setObjectName("camera_main_label")

        # Defines a text label above the screen
        self.camera_title_label=QtWidgets.QLabel(self.centralwidget)
        self.camera_title_label.setGeometry(QtCore.QRect(50, 40, 680, 71))  

        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(22)
        self.camera_title_label.setFont(font)
        self.camera_title_label.setAlignment(QtCore.Qt.AlignCenter)
        self.camera_title_label.setObjectName("camera_title_label")

        # Camera widget
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(50, 90, 700, 400))

        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.layout = QtWidgets.QHBoxLayout(self.verticalLayoutWidget)
        self.layout.setObjectName("layout")
        
        fp = haar_cascade_filepath

        self.face_detection_widget = FaceDetectionWidget(fp)
        self.record_video = RecordVideo()
        image_data_slot = self.face_detection_widget.image_data_slot
        self.record_video.image_data.connect(image_data_slot)

        self.layout.addWidget(self.face_detection_widget)
        self.verticalLayoutWidget.setLayout(self.layout)

        self.setCentralWidget(self.centralwidget)
        self.retranslateUi(self)

    def retranslateUi(self, CameraWindow1):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle(_translate("CameraWindow1", "MainWindow"))
        self.camera_title_label.setText(_translate("CameraWindow1", message_CAMERA1))


class JoinWindow(QtWidgets.QMainWindow, Ui_Join_Window):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Join_Window.__init__(self)
        self.setupUi(self)
        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(32)
        self.label_text.setFont(font)
        self.label_text.setAlignment(QtCore.Qt.AlignCenter)
        self.label_text.setObjectName("label_text")

        font.setPointSize(28)
        self.label_id.setFont(font)
        self.label_id.setAlignment(QtCore.Qt.AlignCenter)
        self.label_id.setObjectName("label_id")

        self.label_sex.setFont(font)
        self.label_sex.setAlignment(QtCore.Qt.AlignCenter)
        self.label_sex.setObjectName("label_sex")

        self.label_phone.setFont(font)
        self.label_phone.setAlignment(QtCore.Qt.AlignCenter)
        self.label_phone.setObjectName("label_phone")
        
        self.pushButton_join_next.clicked.connect(self.Join_next_button_clicked)
        
    def Join_next_button_clicked(self):
        global nickname
        global phone
        global sex
        global camera_flag

        nickname=self.lineEdit_id.text()
        phone=self.lineEdit_phone.text()

        if nickname=="" or phone=="":   # empty
            QMessageBox.information(self, "Empty Field", message_EMPTY1)
            return

        if self.radioButton_man.isChecked():
            sex="man"
        elif self.radioButton_woman.isChecked():
            sex="woman"
    
        else:
             QMessageBox.information(self, "Empty Field", message_EMPTY2)
             return

        if checkPhoneNumber(phone)==0:
            QMessageBox.information(self, "Empty Field", message_PHONE1)
            return

        if len(phone)==13:
            list=phone.split('-')
            phone=list[0]+list[1]+list[2]

        CameraWindow1.record_video.start_recording()        

        # Initialize text
        self.lineEdit_id.clear()
        self.lineEdit_phone.clear()
        
        self.group=QtWidgets.QButtonGroup()

        self.group.addButton(self.radioButton_man)
        self.group.addButton(self.radioButton_woman)
        self.group.setExclusive(False)

        self.radioButton_man.setChecked(False)
        self.radioButton_woman.setChecked(False)

        self.group.setExclusive(True)

        camera_flag=1
        CameraWindow1.showFullScreen()
        self.close()


# Measure Sensor data and change to RecommendWindow
class MeasureWindow(QtWidgets.QMainWindow, Ui_Measure_Window):
    def __init__(self):
        super().__init__()
        QtWidgets.QMainWindow.__init__(self)
        Ui_Measure_Window.__init__(self)
        self.setupUi(self)
        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(28)
        self.label_join_title.setFont(font)
        self.label_join_title.setAlignment(QtCore.Qt.AlignCenter)
        self.label_join_title.setObjectName("label_join_title")


        self.label_join_title2.setFont(font)
        self.label_join_title2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_join_title2.setObjectName("label_join_title2")

    def Measure(self):
        global sensor_result
        global p_flag
        global SpO2
        global heart_rate
        sensor_result = collect_sensor_data()
        if sensor_result == False:
            heart_rate = 61
            if sex == 'woman':
                if age < 25 :
                    p_flag = 1
                elif age >= 25 and age < 35:
                    p_flag = 2
                elif age >= 35:
                    p_flag = 3
                ResultWindow1.label_line_1.setText("여성")
                ResultWindow1.label_line_2.setText(str(age))
                ResultWindow1.label_line_3.setText(str(heart_rate))
                ResultWindow1.label_line_4.setText(str(SpO2))    
                ResultWindow1.label_line_5.setText(weather)                     
                ResultWindow1.showFullScreen()
            else:
                if age < 25 :
                    p_flag = 4
                elif age >= 25 and age < 35:
                    p_flag = 5
                elif age >= 35:
                    p_flag = 6
                ResultWindow1.label_line_1.setText("남성")
                ResultWindow1.label_line_2.setText(str(age))
                ResultWindow1.label_line_3.setText(str(heart_rate))
                ResultWindow1.label_line_4.setText(str(SpO2))    
                ResultWindow1.label_line_5.setText(weather)   
                ResultWindow1.showFullScreen()
        else:
            if SpO2<90:
                SpO2 = 90
            sensor_result = False
            if sex == 'woman':
                if age < 25 :
                    p_flag = 1
                elif age >= 25 and age < 35:
                    p_flag = 2
                elif age >= 35:
                    p_flag = 3
                ResultWindow1.label_line_1.setText("여성")
                ResultWindow1.label_line_2.setText(str(age))
                ResultWindow1.label_line_3.setText(str(heart_rate))
                ResultWindow1.label_line_4.setText(str(SpO2))    
                ResultWindow1.label_line_5.setText(weather)  
                ResultWindow1.showFullScreen()
            else:
                if age < 25 :
                    p_flag = 4
                elif age >= 25 and age < 35:
                    p_flag = 5
                elif age >= 35:
                    p_flag = 6
                ResultWindow1.label_line_1.setText("남성")
                ResultWindow1.label_line_2.setText(str(age))
                ResultWindow1.label_line_3.setText(str(heart_rate))
                ResultWindow1.label_line_4.setText(str(SpO2))    
                ResultWindow1.label_line_5.setText(weather) 
                ResultWindow1.showFullScreen()

# Create TTS mp3 file that recommends beverage to user
# CAUTION : THIS WINDOW MUST BE IMPROVED AND REFINED

class ResultWindow(QtWidgets.QMainWindow, Ui_Result_Window):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Result_Window.__init__(self)
        self.setupUi(self)


        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(28)

        self.label_title.setFont(font)
        self.label_title.setAlignment(QtCore.Qt.AlignCenter)
        self.label_title.setObjectName("label_title")

        font.setPointSize(18)
        self.label_line0.setFont(font)
        self.label_line0.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line0.setObjectName("label_line0")


        self.label_line1.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line1.setObjectName("label_line1")


        self.label_line2.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line2.setObjectName("label_line2")

        self.label_line3.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line3.setObjectName("label_line3")

        self.label_line4.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line4.setObjectName("label_line4")

        self.label_line5.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line5.setObjectName("label_line5")

        self.label_line_1.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line_1.setObjectName("label_line_1")

        self.label_line_2.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line_2.setObjectName("label_line_2")

        self.label_line_3.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line_3.setObjectName("label_line_3")

        self.label_line_4.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line_4.setObjectName("label_line_4")

        self.label_line_5.setAlignment(QtCore.Qt.AlignLeft)
        self.label_line_5.setObjectName("label_line_5")


        self.pushButton_next.clicked.connect(self.next_button_clicked)

    def next_button_clicked(self):
        recommend_menu()
        RecommendWindow4.label_name1.setText(r_menu1)
        RecommendWindow4.label_name2.setText(r_menu2)
        RecommendWindow4.label_name3.setText(r_menu3)

        menu[order_menu[r_menu1]].setGeometry(QtCore.QRect(65,169,191,181))
        menu[order_menu[r_menu2]].setGeometry(QtCore.QRect(325,169,191,181))
        menu[order_menu[r_menu3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        menu[order_menu[r_menu1]].show()
        menu[order_menu[r_menu2]].show()
        menu[order_menu[r_menu3]].show()
        
        RecommendWindow4.showFullScreen()
        self.close()

class RecommendWindow_4(QtWidgets.QMainWindow, Ui_Recommend_Window4):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Recommend_Window4.__init__(self)
        self.setupUi(self)

        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(12)

        self.label_title.setFont(font)
        self.label_title.setAlignment(QtCore.Qt.AlignCenter)
        self.label_title.setObjectName("label_title")

        self.label_name1.setFont(font)
        self.label_name1.setAlignment(QtCore.Qt.AlignCenter)
        self.label_name1.setObjectName("label_name1")        

        self.label_name2.setFont(font)
        self.label_name2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_name2.setObjectName("label_name2") 
        
        self.label_name3.setFont(font)
        self.label_name3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_name3.setObjectName("label_name3") 

        self.pushButton_menu0.hide()
        self.pushButton_menu1.hide()
        self.pushButton_menu2.hide()
        self.pushButton_menu3.hide()
        self.pushButton_menu4.hide()
        self.pushButton_menu5.hide()
        self.pushButton_menu6.hide()
        self.pushButton_menu7.hide()
        self.pushButton_menu8.hide()
        self.pushButton_menu9.hide()
        self.pushButton_menu10.hide()
        self.pushButton_menu11.hide()
        self.pushButton_menu12.hide()
        self.pushButton_menu13.hide()
        self.pushButton_menu14.hide()
        self.pushButton_menu15.hide()
        self.pushButton_menu16.hide()
        self.pushButton_menu17.hide()
 

        self.pushButton_menu0.clicked.connect(self.menu0_button_clicked)
        self.pushButton_menu1.clicked.connect(self.menu1_button_clicked)
        self.pushButton_menu2.clicked.connect(self.menu2_button_clicked)
        self.pushButton_menu3.clicked.connect(self.menu3_button_clicked)
        self.pushButton_menu4.clicked.connect(self.menu4_button_clicked)
        self.pushButton_menu5.clicked.connect(self.menu5_button_clicked)
        self.pushButton_menu6.clicked.connect(self.menu6_button_clicked)
        self.pushButton_menu7.clicked.connect(self.menu7_button_clicked)
        self.pushButton_menu8.clicked.connect(self.menu8_button_clicked)
        self.pushButton_menu9.clicked.connect(self.menu9_button_clicked)
        self.pushButton_menu10.clicked.connect(self.menu10_button_clicked)
        self.pushButton_menu11.clicked.connect(self.menu11_button_clicked)
        self.pushButton_menu12.clicked.connect(self.menu12_button_clicked)
        self.pushButton_menu13.clicked.connect(self.menu13_button_clicked)
        self.pushButton_menu14.clicked.connect(self.menu14_button_clicked)
        self.pushButton_menu15.clicked.connect(self.menu15_button_clicked)
        self.pushButton_menu16.clicked.connect(self.menu16_button_clicked)
        self.pushButton_menu17.clicked.connect(self.menu17_button_clicked)

    def menu0_button_clicked(self):
        global final_order_menu
        final_order_menu="과일&치즈샐러드"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)

        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        
        RecommendWindow5.showFullScreen()
        self.close()
    def menu1_button_clicked(self):
        global final_order_menu
        final_order_menu="라자냐샐러드"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()

        RecommendWindow5.showFullScreen()
        self.close()
    def menu2_button_clicked(self):
        global final_order_menu
        final_order_menu="비프스테이크수퍼보울"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu3_button_clicked(self):
        global final_order_menu
        final_order_menu="비프크림파스타"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()

        RecommendWindow5.showFullScreen()
        self.close()
    def menu4_button_clicked(self):
        global final_order_menu
        final_order_menu="쉬림프누들수퍼보울"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)

        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu5_button_clicked(self):
        global final_order_menu
        final_order_menu="쉬림프로제파스타"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)

        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu6_button_clicked(self):
        global final_order_menu
        final_order_menu="씨푸드파스타"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)

        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu7_button_clicked(self):
        global final_order_menu
        final_order_menu="아보카도샌드위치"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)

        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu8_button_clicked(self):
        global final_order_menu
        final_order_menu="아보카도연어샐러드"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)

        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu9_button_clicked(self):
        global final_order_menu
        final_order_menu="연어샌드위치"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu10_button_clicked(self):
        global final_order_menu
        final_order_menu="연어스테이크수퍼보울"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu11_button_clicked(self):
        global final_order_menu
        final_order_menu="치킨그레인샐러드"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu12_button_clicked(self):
        global final_order_menu
        final_order_menu="치킨샌드위치"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu13_button_clicked(self):
        global final_order_menu
        final_order_menu="치킨스테이크수퍼보울"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu14_button_clicked(self):
        global final_order_menu
        final_order_menu="카프레제샐러드"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu15_button_clicked(self):
        global final_order_menu
        final_order_menu="케일치킨시저샐러드"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu16_button_clicked(self):
        global final_order_menu
        final_order_menu="필리치즈스테이크샌드위치"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)
        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))
    
        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
    def menu17_button_clicked(self):
        global final_order_menu
        final_order_menu="햄&치즈샐러드"
        RecommendWindow5.label_name1.setText(r_drink1)
        RecommendWindow5.label_name2.setText(r_drink2)
        RecommendWindow5.label_name3.setText(r_drink3)

        drink[order_drink[r_drink1]].setGeometry(QtCore.QRect(65,169,191,181))
        drink[order_drink[r_drink2]].setGeometry(QtCore.QRect(325,169,191,181))
        drink[order_drink[r_drink3]].setGeometry(QtCore.QRect(575,169,191,181))

        drink[order_drink[r_drink1]].show()
        drink[order_drink[r_drink2]].show()
        drink[order_drink[r_drink3]].show()
        RecommendWindow5.showFullScreen()
        self.close()
class RecommendWindow_5(QtWidgets.QMainWindow, Ui_Recommend_Window5):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Recommend_Window5.__init__(self)
        self.setupUi(self)

        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(12)

        self.label_title.setFont(font)
        self.label_title.setAlignment(QtCore.Qt.AlignCenter)
        self.label_title.setObjectName("label_title")

        self.label_name1.setFont(font)
        self.label_name1.setAlignment(QtCore.Qt.AlignCenter)
        self.label_name1.setObjectName("label_name1")        

        self.label_name2.setFont(font)
        self.label_name2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_name2.setObjectName("label_name2") 
        
        self.label_name3.setFont(font)
        self.label_name3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_name3.setObjectName("label_name3") 

        self.pushButton_drink0.hide()
        self.pushButton_drink1.hide()
        self.pushButton_drink2.hide()
        self.pushButton_drink3.hide()
        self.pushButton_drink4.hide()
        self.pushButton_drink5.hide()
        self.pushButton_drink6.hide()
        self.pushButton_drink7.hide()
        self.pushButton_drink8.hide()
        self.pushButton_drink9.hide()
        self.pushButton_drink10.hide()
        self.pushButton_drink11.hide()
        self.pushButton_drink12.hide()
        self.pushButton_drink13.hide()
        self.pushButton_drink14.hide()
        self.pushButton_drink15.hide()
        self.pushButton_drink16.hide()
 
        self.pushButton_drink0.clicked.connect(self.drink0_button_clicked)
        self.pushButton_drink1.clicked.connect(self.drink1_button_clicked)
        self.pushButton_drink2.clicked.connect(self.drink2_button_clicked)
        self.pushButton_drink3.clicked.connect(self.drink3_button_clicked)
        self.pushButton_drink4.clicked.connect(self.drink4_button_clicked)
        self.pushButton_drink5.clicked.connect(self.drink5_button_clicked)
        self.pushButton_drink6.clicked.connect(self.drink6_button_clicked)
        self.pushButton_drink7.clicked.connect(self.drink7_button_clicked)
        self.pushButton_drink8.clicked.connect(self.drink8_button_clicked)
        self.pushButton_drink9.clicked.connect(self.drink9_button_clicked)
        self.pushButton_drink10.clicked.connect(self.drink10_button_clicked)
        self.pushButton_drink11.clicked.connect(self.drink11_button_clicked)
        self.pushButton_drink12.clicked.connect(self.drink12_button_clicked)
        self.pushButton_drink13.clicked.connect(self.drink13_button_clicked)
        self.pushButton_drink14.clicked.connect(self.drink14_button_clicked)
        self.pushButton_drink15.clicked.connect(self.drink15_button_clicked)
        self.pushButton_drink16.clicked.connect(self.drink16_button_clicked)

    def drink0_button_clicked(self):
        global final_order_drink
        final_order_drink = "그래스쿨러(사과,신선초)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink1_button_clicked(self):
        global final_order_drink
        final_order_drink="그린웨이브(밀싹,케일)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink2_button_clicked(self):
        global final_order_drink
        final_order_drink="그린호프(케일,샐러리)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink3_button_clicked(self):
        global final_order_drink
        final_order_drink="당근&비트주스"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink4_button_clicked(self):
        global final_order_drink
        final_order_drink="딸기주스"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink5_button_clicked(self):
        global final_order_drink
        final_order_drink="버진컴백(사과,샐러리)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink6_button_clicked(self):
        global final_order_drink
        final_order_drink="블루베리&애플주스"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink7_button_clicked(self):
        global final_order_drink
        final_order_drink="비트부스터(비트,오렌지)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink8_button_clicked(self):
        global final_order_drink
        final_order_drink="스윗조이(파인애플,사과)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink9_button_clicked(self):
        global final_order_drink
        final_order_drink="스카이워커(당근,사과)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink10_button_clicked(self):
        global final_order_drink
        final_order_drink="오렌지&애플주스"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink11_button_clicked(self):
        global final_order_drink
        final_order_drink="젠틀바인(비트,자몽)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink12_button_clicked(self):
        global final_order_drink
        final_order_drink="케일&애플주스"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink13_button_clicked(self):
        global final_order_drink
        final_order_drink="파인애플&애플주스"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink14_button_clicked(self):
        global final_order_drink
        final_order_drink="패스트리스토어(사과,케일)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink15_button_clicked(self):
        global final_order_drink
        final_order_drink="프로틴블루베리스무디"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()
    def drink16_button_clicked(self):
        global final_order_drink
        final_order_drink="해피오렌지(오렌지,당근)"
        FinalWindow1.label_name1.setText(final_order_menu)
        FinalWindow1.label_name2.setText(final_order_drink)
        f_menu[order_menu[final_order_menu]].setGeometry(QtCore.QRect(100,130,250,250))
        f_drink[order_drink[final_order_drink]].setGeometry(QtCore.QRect(450,130,250,250))
        f_menu[order_menu[final_order_menu]].show()
        f_drink[order_drink[final_order_drink]].show()
        createMp3(UserName,final_order_menu,final_order_drink)
        FinalWindow1.play()
        FinalWindow1.showFullScreen()
        self.close()

class SurveyWindow(QtWidgets.QMainWindow, Ui_Survey_Window):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Survey_Window.__init__(self)
        self.setupUi(self)


        ########phillip############

        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(24)
        self.label_title.setFont(font)
        self.label_title.setAlignment(QtCore.Qt.AlignCenter)
        self.label_title.setObjectName("label_title")

        font.setPointSize(12)
        self.pushButton1.setFont(font)
        self.pushButton1.setObjectName("pushButton1")

        self.pushButton2.setFont(font)
        self.pushButton2.setObjectName("pushButton2")

        self.pushButton3.setFont(font)
        self.pushButton3.setObjectName("pushButton3")

        self.pushButton4.setFont(font)
        self.pushButton4.setObjectName("pushButton4")

        self.pushButton5.setFont(font)
        self.pushButton5.setObjectName("pushButton5")

        #############################
        font.setPointSize(10)
        self.label_1.setFont(font)
        self.label_1.setObjectName("label_1")

        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")

        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")

        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")

        self.label_5.setFont(font)
        self.label_5.setObjectName("label_5")

        
        self.pushButton1.clicked.connect(self.pushButton1_button_clicked)
        self.pushButton2.clicked.connect(self.pushButton2_button_clicked)
        self.pushButton3.clicked.connect(self.pushButton3_button_clicked)
        self.pushButton4.clicked.connect(self.pushButton4_button_clicked)
        self.pushButton5.clicked.connect(self.pushButton5_button_clicked)
        
    def pushButton1_button_clicked(self):
        global survey_num

        survey_num=1
        FinishWindow1.showFullScreen()
        FinishWindow1.Recommend()
        self.close()
                
    def pushButton2_button_clicked(self):
        global survey_num

        survey_num=2
        FinishWindow1.showFullScreen()
        FinishWindow1.Recommend()
        self.close()
    def pushButton3_button_clicked(self):
        global survey_num

        survey_num=3
        FinishWindow1.showFullScreen()
        FinishWindow1.Recommend()
        self.close()
                
    def pushButton4_button_clicked(self):
        global survey_num

        survey_num=4
        FinishWindow1.showFullScreen()
        FinishWindow1.Recommend()
        self.close()
    def pushButton5_button_clicked(self):
        global survey_num

        survey_num=5
        FinishWindow1.showFullScreen()
        FinishWindow1.Recommend()
        self.close()



class FinalWindow(QtWidgets.QMainWindow, Ui_Final_Window):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Final_Window.__init__(self)
        self.setupUi(self)

        ########phillip############

        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(12)

        self.label_title.setFont(font)
        self.label_title.setAlignment(QtCore.Qt.AlignCenter)
        self.label_title.setObjectName("label_title")

        self.label_name1.setFont(font)
        self.label_name1.setAlignment(QtCore.Qt.AlignCenter)
        self.label_name1.setObjectName("label_name1")        

        self.label_name2.setFont(font)
        self.label_name2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_name2.setObjectName("label_name2") 

        #############################
        self.pushButton_menu0.hide()
        self.pushButton_menu1.hide()
        self.pushButton_menu2.hide()
        self.pushButton_menu3.hide()
        self.pushButton_menu4.hide()
        self.pushButton_menu5.hide()
        self.pushButton_menu6.hide()
        self.pushButton_menu7.hide()
        self.pushButton_menu8.hide()
        self.pushButton_menu9.hide()
        self.pushButton_menu10.hide()
        self.pushButton_menu11.hide()
        self.pushButton_menu12.hide()
        self.pushButton_menu13.hide()
        self.pushButton_menu14.hide()
        self.pushButton_menu15.hide()
        self.pushButton_menu16.hide()
        self.pushButton_menu17.hide()

        self.pushButton_drink0.hide()
        self.pushButton_drink1.hide()
        self.pushButton_drink2.hide()
        self.pushButton_drink3.hide()
        self.pushButton_drink4.hide()
        self.pushButton_drink5.hide()
        self.pushButton_drink6.hide()
        self.pushButton_drink7.hide()
        self.pushButton_drink8.hide()
        self.pushButton_drink9.hide()
        self.pushButton_drink10.hide()
        self.pushButton_drink11.hide()
        self.pushButton_drink12.hide()
        self.pushButton_drink13.hide()
        self.pushButton_drink14.hide()
        self.pushButton_drink15.hide()
        self.pushButton_drink16.hide()

        self.pushButton_next.clicked.connect(self.next_button_clicked)

    def play(self):
        readMp3File()
    def next_button_clicked(self):
        f_menu[order_menu[final_order_menu]].hide()
        f_drink[order_drink[final_order_drink]].hide()
        SurveyWindow1.showFullScreen()

        self.close()

# If the user tries to login but FaceAPI returns Fail
# Get userdata like phone number to identify who the user is
class FailWindow(QtWidgets.QMainWindow, Ui_Fail_Window):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Fail_Window.__init__(self)
        self.setupUi(self)
        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(24)
        self.label_fail_text.setFont(font)
        self.label_fail_text.setAlignment(QtCore.Qt.AlignCenter)
        self.label_fail_text.setObjectName("label_fail_text")


        font.setPointSize(28)
        self.label_fail_phone.setFont(font)
        self.label_fail_phone.setAlignment(QtCore.Qt.AlignCenter)
        self.label_fail_phone.setObjectName("label_fail_phone")
        self.pushButton_fail_next.clicked.connect(self.Fail_next_button_clicked)

    def Fail_next_button_clicked(self):
        global phone
        global age
        global UserName
        global sex
        global faceinfo
        phone=self.lineEdit_fail_phone.text()
    
        if phone=="":
            QMessageBox.information(self, "Empty Field", message_EMPTY1)
            return

        if checkPhoneNumber(phone)==0:
            QMessageBox.information(self, "Empty Field", message_PHONE1)
            return

        if len(phone)==13:
            list=phone.split('-')
            phone=list[0]+list[1]+list[2]
        
        p_data={'phone':phone}
        rep3=requests.get(cfg_SERVER_URL3,params=p_data)
        rp_data = rep3.json()
        print(rp_data)
        age = rp_data['age']
        if age == -1:
            self.lineEdit_fail_phone.clear()
            QMessageBox.information(self, "Empty Field", message_PHONE2)
            MainWindow1.showFullScreen()
            self.close()
        else:
            sex = rp_data['sex']
            UserName = rp_data['name']
            person_id2 = rp_data['person_id']
            faceinfo = rp_data['faceinfo']
            self.lineEdit_fail_phone.clear()
            MeasureWindow1.showFullScreen()
            MeasureWindow1.Measure()
            self.close()

# play TTS mp3 created in RecommendWindow
# update weather info and go back to MainWindow
class FinishWindow(QtWidgets.QMainWindow, Ui_Finish_Window):
    def __init__(self):
        QtWidgets.QMainWindow.__init__(self)
        Ui_Finish_Window.__init__(self)
        self.setupUi(self)

        font = QtGui.QFont()
        font.setFamily(cfg_FONTS)
        font.setPointSize(40)
        self.label_finish_title.setFont(font)
        self.label_finish_title.setAlignment(QtCore.Qt.AlignCenter)
        self.label_finish_title.setObjectName("label_finish_title")

    def Recommend(self):
        #readMp3File()
        global camera_flag
        global faces
        global p_flag
        global b_flag
        global m_flag
        global UserName     
        global person_id
        global person_id2
        global final_order_menu
        global final_order_drink
        global heart_rate        
        global SpO2              
        global store_temp        
        global store_humidity
        global nickname  
        global phone            
        global sex             
        global temp              
        global weather          
        global age 
        global faceinfo                  
        global sensor_result
        global login_flag
        global r_menu1
        global r_menu2
        global r_menu3
        global r_drink1
        global r_drink2
        global r_drink3
        global survey_num
        collect_weather_info()

        if login_flag==0:       # Join
            #data={'id':nickname, 'phone':phone,'sex':sex,'weather':weather,'personid':person_id,'age':faceinfo['age'],'storeid':cfg_LOCATION, 'temp':temp,'faceinfo':json.dumps(faceinfo)}
            #print(data)
            #print(SpO2)
            #rep=requests.post(cfg_SERVER_URL,json=data)
            server_data={'food':final_order_menu,'age':age,'sex':sex,'drink':final_order_drink,'id':nickname,'weather':weather,'personid':person_id,'storeid':cfg_LOCATION, 'temp':temp,'faceinfo':json.dumps(faceinfo),'heart':heart_rate,'spo2':SpO2,'grade':survey_num}
            rep2=requests.post(cfg_SERVER_URL4,json=server_data)
            #print(rep.text)
        else:
            data={'food':final_order_menu,'age':age,'sex':sex,'drink':final_order_drink,'id':UserName,'weather':weather,'personid':person_id2,'storeid':cfg_LOCATION, 'temp':temp,'faceinfo':json.dumps(faceinfo),'heart':heart_rate,'spo2':SpO2,'grade':survey_num}
            print(data)
            rep=requests.post(cfg_SERVER_URL4,json=data)
            login_flag=0
            #print(age)
        faces=0
        p_flag = 0
        b_flag = 0
        m_flag = 0
        camera_flag=0
        UserName = ''     
        person_id = ''
        person_id2 = ''
        final_order_menu=""
        final_order_drink=""
        heart_rate=0        
        SpO2=0              
        store_temp=0        
        store_humidity=0
        nickname=''  
        phone=''            
        sex=''             
        temp=0              
        weather=''          
        age=0 
        faceinfo = {}                  
        sensor_result = False
        menu[order_menu[r_menu1]].hide()
        menu[order_menu[r_menu2]].hide()
        menu[order_menu[r_menu3]].hide() 
        drink[order_drink[r_drink1]].hide()
        drink[order_drink[r_drink2]].hide()
        drink[order_drink[r_drink3]].hide()
        r_menu1 = ''
        r_menu2 = ''
        r_menu3 = ''
        r_drink1 = ''
        r_drink2 = ''
        r_drink3 = ''
        survey_num = 0
        MainWindow1.showFullScreen()
        

if __name__ == "__main__":
    global menu
    global drink
    global f_menu
    global f_drink
    script_dir = path.dirname(path.realpath(__file__))
    haar_cascade_filepath = path.join(script_dir,
                                 '..',
                                 'data',
                                 #'C:/Users/new/Desktop/uic/haarcascade_frontalface_default.xml')
                                 cfg_MAIN_DIR + '/haarcascade_frontalface_default.xml')
    haar_cascade_filepath = path.abspath(haar_cascade_filepath)
    app = QtWidgets.QApplication(sys.argv)
    
    MainWindow1=MainWindow()
    LoginWindow1=LoginWindow()
    CameraWindow1=CameraWindow(haar_cascade_filepath)
    JoinWindow1=JoinWindow()
    MeasureWindow1=MeasureWindow()

    ResultWindow1=ResultWindow()
    RecommendWindow4=RecommendWindow_4()
    RecommendWindow5=RecommendWindow_5()
    menu = [RecommendWindow4.pushButton_menu0,RecommendWindow4.pushButton_menu1,RecommendWindow4.pushButton_menu2,RecommendWindow4.pushButton_menu3,RecommendWindow4.pushButton_menu4,RecommendWindow4.pushButton_menu5,RecommendWindow4.pushButton_menu6,RecommendWindow4.pushButton_menu7,RecommendWindow4.pushButton_menu8,RecommendWindow4.pushButton_menu9,RecommendWindow4.pushButton_menu10,RecommendWindow4.pushButton_menu11,RecommendWindow4.pushButton_menu12,RecommendWindow4.pushButton_menu13,RecommendWindow4.pushButton_menu14,RecommendWindow4.pushButton_menu15,RecommendWindow4.pushButton_menu16,RecommendWindow4.pushButton_menu17]
    drink = [RecommendWindow5.pushButton_drink0,RecommendWindow5.pushButton_drink1,RecommendWindow5.pushButton_drink2,RecommendWindow5.pushButton_drink3,RecommendWindow5.pushButton_drink4,RecommendWindow5.pushButton_drink5,RecommendWindow5.pushButton_drink6,RecommendWindow5.pushButton_drink7,RecommendWindow5.pushButton_drink8,RecommendWindow5.pushButton_drink9,RecommendWindow5.pushButton_drink10,RecommendWindow5.pushButton_drink11,RecommendWindow5.pushButton_drink12,RecommendWindow5.pushButton_drink13,RecommendWindow5.pushButton_drink14,RecommendWindow5.pushButton_drink15,RecommendWindow5.pushButton_drink16]
    FailWindow1=FailWindow()
    FinishWindow1=FinishWindow()
    SurveyWindow1=SurveyWindow()
    FinalWindow1=FinalWindow() 
    f_menu = [FinalWindow1.pushButton_menu0,FinalWindow1.pushButton_menu1,FinalWindow1.pushButton_menu2,FinalWindow1.pushButton_menu3,FinalWindow1.pushButton_menu4,FinalWindow1.pushButton_menu5,FinalWindow1.pushButton_menu6,FinalWindow1.pushButton_menu7,FinalWindow1.pushButton_menu8,FinalWindow1.pushButton_menu9,FinalWindow1.pushButton_menu10,FinalWindow1.pushButton_menu11,FinalWindow1.pushButton_menu12,FinalWindow1.pushButton_menu13,FinalWindow1.pushButton_menu14,FinalWindow1.pushButton_menu15,FinalWindow1.pushButton_menu16,FinalWindow1.pushButton_menu17]
    f_drink = [FinalWindow1.pushButton_drink0,FinalWindow1.pushButton_drink1,FinalWindow1.pushButton_drink2,FinalWindow1.pushButton_drink3,FinalWindow1.pushButton_drink4,FinalWindow1.pushButton_drink5,FinalWindow1.pushButton_drink6,FinalWindow1.pushButton_drink7,FinalWindow1.pushButton_drink8,FinalWindow1.pushButton_drink9,FinalWindow1.pushButton_drink10,FinalWindow1.pushButton_drink11,FinalWindow1.pushButton_drink12,FinalWindow1.pushButton_drink13,FinalWindow1.pushButton_drink14,FinalWindow1.pushButton_drink15,FinalWindow1.pushButton_drink16]
    collect_weather_info()
    MeasureWindow1.showFullScreen()
    FinishWindow1.showFullScreen()
    MainWindow1.showFullScreen()

    sys.exit(app.exec_())

