#!/usr/bin/env python


# retranslateUi
msg_CAMERA1_KOR = '<고객님의 얼굴을 인식 중입니다. 가까이 와 주세요>'
msg_CAMERA1_ENG = '<Your face is being recognized. Please come closer>'


# Join_next_button_clicked & Fail_next_button_clicked
msg_EMPTY1_KOR = '정보를 입력해 주세요'
msg_EMPTY1_ENG = 'Please enter information'

msg_EMPTY2_KOR = '성별을 선택해 주세요'
msg_EMPTY2_ENG = 'Please select gender'

msg_PHONE1_KOR = '전화번호 형식이 틀렸습니다'
msg_PHONE1_ENG = 'Phone number format is wrong'

msg_PHONE2_KOR = '전화번호가 등록되어 있지 않습니다. 회원가입이나 다시 입력해주세요'
msg_PHONE2_ENG = 'Phone number format is wrong'

msg_SENSOR1_KOR = '센서 측정이 정확하지 않아 다시 한번 정보를 수정 하겠습니다'