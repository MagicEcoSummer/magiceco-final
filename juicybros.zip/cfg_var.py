#!/usr/bin/env python


## client.py ##

cfg_SERVER_URL = 'http://35.226.62.202:3000/user'

cfg_SERVER_URL2 = 'http://35.226.62.202:3000/information'

cfg_SERVER_URL3 = 'http://35.226.62.202:3000/phone'

cfg_SERVER_URL4 = 'http://35.226.62.202:3000/order'

# Location to collect Weather info
cfg_LOCATION = '청진동'

cfg_FONTS = 'Noto Sans B'

cfg_MAIN_DIR = '/home/pi/juicybros'



## FaceAPI.py ##

cfg_FACE_SUB_KEY = '3da8e55514df44ed900559b994a55ac8'

cfg_FACE_SERV_AREA = 'southeastasia'


## SpeechAPI.py ##

cfg_SPEECH_SUB_KEY = '3e71830054e54dbdb45e8a499500e255'

cfg_SPEECH_SERV_AREA = 'southeastasia'
